export class KeyCustomers {
  id?: any;
  index?: any;
  type?: any;
  segment?: string;
  nameClient?: string;
  clientAccountPlan?: string;
  sol?: any = [{sol: '', index: 0}];
  totalCustomerSale?: string;
}
