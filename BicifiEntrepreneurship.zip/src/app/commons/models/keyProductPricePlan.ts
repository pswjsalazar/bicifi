export class KeyProductPricePlan {
  id?: any;
  index?: any;
  criticalProductCharacteristics?: any;
  weightImportanceClient?: any;
  product = [{evaluationEachCharacteristic: '', index: 0}];
}
