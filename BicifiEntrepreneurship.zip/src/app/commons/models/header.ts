export class Header {
  id?: string;
  index?: number;
  columnName?: string;
  price?: string;
}
