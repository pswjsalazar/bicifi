export class Plan {
  id?: string;
  index?: number;
  barrier: any;
  segmentName: any;
  strategyEliminateBarrier: any;
  project = [{name: ''}];
  metrics = [{name: ''}];
  who = [{name: ''}];
  when = [{name: ''}];
  state = [{name: ''}];
}
