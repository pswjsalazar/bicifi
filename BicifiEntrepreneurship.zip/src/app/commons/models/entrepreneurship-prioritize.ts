export class EntrepreneurshipPrioritize {
  id?: string;
  index?: number;
  typeProject?: any;
  nameProject?: any;
  levelSales?: any;
  percentExit?: any;
  timeComplete?: any;
  scoreProject?: any;
  leaderName?: any;
  labelYear?: any = [];
}
