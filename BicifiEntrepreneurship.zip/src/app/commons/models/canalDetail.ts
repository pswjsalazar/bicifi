export class CanalDetail {
  id?: string;
  index?: number;
  name: any;
  shareData: any;
  exclusive: any;
  assignedTerritory: any;
  contract: any;
  idIntermediaryChannel: string;
}
