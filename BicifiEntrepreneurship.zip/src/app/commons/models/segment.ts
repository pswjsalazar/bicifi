export class Segment {
  id?: string;
  index?: number;
  segmentName: any;
  valueProposal: any;
  percentSellers: any;
  percentProfit: any;
  briefcase: any;
  value: any;
}
