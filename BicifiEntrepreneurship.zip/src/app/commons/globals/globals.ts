export const globals = {};
