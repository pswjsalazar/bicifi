export const environment = {
  production: true,
  firebase: {
    apiKey: 'AIzaSyDbT-qIJuVMOstqq1lJNmU6lsgZsJSJasc',
    authDomain: 'bicifientrepreneurship.firebaseapp.com',
    projectId: 'bicifientrepreneurship',
    storageBucket: 'bicifientrepreneurship.appspot.com',
    messagingSenderId: '428129516561',
    appId: '1:428129516561:web:584e27be6eb2d07a6405b0',
    measurementId: 'G-WWYFKS6BED'
  }
};
